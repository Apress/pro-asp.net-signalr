﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GroupBrush.Entity
{
    public class CanvasName
    {
        public string Name;
    }
}
