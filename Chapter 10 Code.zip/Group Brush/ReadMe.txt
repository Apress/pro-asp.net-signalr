To run the example on the Emulator you must run Visual Studio as an administrator.
For any the example will run the GroupBrushDB setting must be set to a valid connection string.
To run the example using Redis as a message backplane, the UseRedis setting must be set to true
and have valid values for the following settings: GroupBrushRedisHostname and GroupBrushRedisPassword