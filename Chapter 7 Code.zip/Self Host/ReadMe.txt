Make sure you run the example as Administrator.
Make sure that you allow the port to be accessed by running the following
 command as administrator from the command prompt:
netsh http add urlacl url=http://localhost:5045/ user=machine\username